import ghidra.app.script.GhidraScript;
import ghidra.app.services.ConsoleService;
import ghidra.app.util.bin.StructConverter;
import ghidra.framework.store.LockException;
import ghidra.program.model.address.Address;
import ghidra.program.model.data.CategoryPath;
import ghidra.program.model.data.ImageBaseOffset32DataType;
import ghidra.program.model.data.StructureDataType;
import ghidra.program.model.listing.CodeUnit;
import ghidra.program.model.listing.Listing;
import ghidra.program.model.mem.MemoryAccessException;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.util.exception.DuplicateNameException;
import org.apache.commons.io.FileUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

import static ghidra.program.model.listing.CodeUnit.EOL_COMMENT;

@SuppressWarnings("Duplicates")
public class SelfAnalyzer extends GhidraScript {


    JSONObject jsonObject = null;

    Listing listing;

    @Override
    protected void run() throws Exception {

        jsonObject = new JSONObject(FileUtils.readFileToString(new File("G:\\Projects 2019\\lv2\\ps3ida\\ps3fnids.json")));

        listing = currentProgram.getListing();

        MemoryBlock opt_seg = findOpd();
        if(opt_seg == null) {
            printerr("Could not find the OPD segment\n");
            return;
        }

        Address toc = findToc(opt_seg);
        if(toc == null) {
            printerr("Could not find the TOC\n");
            return;
        }

        printf("Found TOC at 0x%X\n", toc.getOffset());
        createOpd(toc);
        findImportsExports();


    }

    private void findImportsExports() throws Exception {
        createImportStruc();
        createExportStruc();

        printf("Finding Import/Export structure\n");

        MemoryBlock export_start_block = null;
        Address export_start = null;
        Address export_end = null;
        long ea;
        for (MemoryBlock block : currentProgram.getMemory().getBlocks()) {
            if(block.getSize() % 0x1C != 0) {
                continue;
            }

            for (ea = block.getStart().getOffset(); ea + 0x1c < block.getEnd().getOffset(); ea = ea + 0x1C) {
                int size = listing.getCodeUnitAt(block.getStart().getNewAddress(ea)).getShort(0);
                if(size != 0x1C00) {
                    break;
                }
                export_start_block = block;
                export_start = block.getStart();
            }
        }

        if(export_start_block != null) {
            println("found export start block");
            export_end = export_start_block.getEnd();
            export_start_block.setName("Exports");
            printf("Found Export Table: 0x%X\n", export_start.getOffset());
            createExports(export_start, export_end);
        }

        MemoryBlock import_start_block = null;
        Address import_start = null;
        Address import_end = null;
        for (MemoryBlock block : currentProgram.getMemory().getBlocks()) {
            if(block == export_start_block)
                continue;

            if(block.getSize() % 0x1C != 0) {
                continue;
            }

            for (ea = block.getStart().getOffset(); ea + 0x2c < block.getEnd().getOffset(); ea = ea + 0x2c) {
                int size = listing.getCodeUnitAt(block.getStart().getNewAddress(ea)).getShort(0);
                if(size != 0x2C00) {
                    break;
                }

                import_start_block = block;
                import_start = block.getStart();
            }
        }

        if(import_start_block != null) {
            import_end = import_start_block.getEnd();
            import_start_block.setName("Imports");
            printf("Found Import Table: 0x%X\n", import_start.getOffset());
            createImports(import_start, import_end);
        }

    }

    private void createImports(Address import_start, Address import_end) throws Exception {
        println("Defining Import stubs");

        long ea;
        for(ea = import_start.getOffset(); ea < import_end.getOffset(); ea = ea + 0x2c) {
            Address struc_addr = import_start.getNewAddress(ea);
            applyStruct(importStructDataType, struc_addr);
            CodeUnit import_struct_entry = listing.getCodeUnitAt(struc_addr);

            int imports = import_struct_entry.getShort(0x06);

            int name_ptr = import_struct_entry.getInt(0x10);
            Address nameptrAddr = import_start.getNewAddress(name_ptr);
            createAsciiString(nameptrAddr);
            String name = (String) listing.getDataAt(nameptrAddr).getValue();

            int fnid_ptr = import_struct_entry.getInt(0x14);
            createLabel(import_start.getNewAddress(fnid_ptr), "FNIDTable_"+name, true);
            int stub_ptr = import_struct_entry.getInt(0x18);
            createLabel(import_start.getNewAddress(stub_ptr), "StubTable_"+name, true);
            for (int i = 0; i < imports; i++) {
                Address newfnid_addr = import_start.getNewAddress(fnid_ptr + (i * 4));
                createDWord(newfnid_addr);
                int fnid = listing.getCodeUnitAt(newfnid_addr).getInt(0);
                String fnid_name = get_fnid_name(name, fnid);
                listing.setComment(newfnid_addr, EOL_COMMENT, "Import "+name+"("+i+"): FNID 0x"+Integer.toHexString(fnid)+" : "+fnid_name);

                Address newstub_addr = import_start.getNewAddress(stub_ptr + (i * 4));
                createData(newstub_addr, ImageBaseOffset32DataType.DEFAULT);
                int stub = listing.getCodeUnitAt(newstub_addr).getInt(0);
                createFunction(struc_addr.getNewAddress(stub), "_"+name+"_"+fnid_name);
                String fnid_comment = get_fnid_comment(name, fnid);
                if(!fnid_comment.isEmpty()) {
                    listing.setComment(struc_addr.getNewAddress(stub), EOL_COMMENT, fnid_comment);
                }
            }


        }

    }

    private void createExports(Address export_start, Address export_end) throws Exception {
        println("Defining Export stubs");

        long ea;
        String name = "";
        for(ea = export_start.getOffset(); ea < export_end.getOffset(); ea = ea + 0x1C) {
            Address struc_addr = export_start.getNewAddress(ea);
            applyStruct(exportStructDataType, struc_addr);
            CodeUnit export_struct_entry = listing.getCodeUnitAt(struc_addr);

            int exports = export_struct_entry.getShort(0x06);
            int name_ptr = export_struct_entry.getInt(0x10);
            if(name_ptr == 0) {
                name = "";
            } else {
                Address nameptrAddr = export_start.getNewAddress(name_ptr);
                createAsciiString(nameptrAddr);
                name = (String) listing.getDataAt(nameptrAddr).getValue();
            }

            int fnid_ptr = export_struct_entry.getInt(0x14);
            createLabel(export_start.getNewAddress(fnid_ptr), "ExportFNIDTable_"+name, true);
            int stub_ptr = export_struct_entry.getInt(0x18);
            createLabel(export_start.getNewAddress(stub_ptr), "ExportStubTable_"+name, true);
            for (int i = 0; i < exports; i++) {
                Address newfnid_addr = export_start.getNewAddress(fnid_ptr + (i * 4));
                createDWord(newfnid_addr);
                int fnid = listing.getCodeUnitAt(newfnid_addr).getInt(0);
                String fnid_name = get_fnid_name(name, fnid);
                listing.setComment(newfnid_addr, EOL_COMMENT, "Export "+name+"("+i+"): FNID 0x"+Integer.toHexString(fnid)+" : "+fnid_name);

                Address newstub_addr = export_start.getNewAddress(stub_ptr + (i * 4));
                createData(newstub_addr, ImageBaseOffset32DataType.DEFAULT);
                int stub_opd = listing.getCodeUnitAt(newstub_addr).getInt(0);
                createLabel(struc_addr.getNewAddress(stub_opd), "_Export_"+name+"_"+get_fnid_name(name, fnid)+"_opd", true);
                int stub = listing.getCodeUnitAt(export_start.getNewAddress(stub_opd)).getInt(0);
                createFunction(struc_addr.getNewAddress(stub), "_Export_"+name+"_"+fnid_name);
                String fnid_comment = get_fnid_comment(name, fnid);
                if(!fnid_comment.isEmpty()) {
                    listing.setComment(struc_addr.getNewAddress(stub), EOL_COMMENT, fnid_comment);
                }

            }



        }

    }

    private String get_fnid_comment(String name, int fnid) {
        return "";//TODO
    }

    private String get_fnid_name(String moduleName, int fnid) throws IOException {

        System.out.println(jsonObject);

        JSONObject groups = jsonObject.getJSONObject("Groups");
        if (groups.has(moduleName)) {
            JSONArray entries = groups.getJSONObject(moduleName).getJSONArray("Entry");
            for (int i = 0; i < entries.length(); i++) {
                JSONObject entry = entries.getJSONObject(i);
                if(entry.getString("_id").equals(String.format("0x%08X", fnid))) {
                    return entry.getString("_name");
                }
            }
        }

        printf("Missing fnid, module: %s 0x%08X\n", moduleName, fnid);

        return "0x"+Integer.toHexString(fnid);
    }


    StructureDataType importStructDataType;
    private void createImportStruc() {
        importStructDataType = new StructureDataType(new CategoryPath("/PS3"), "ImportStub_s", 0);
        importStructDataType.add(StructConverter.WORD, "ssize", null);
        importStructDataType.add(StructConverter.WORD, "header1", null);
        importStructDataType.add(StructConverter.WORD, "header2", null);
        importStructDataType.add(StructConverter.WORD, "imports", null);
        importStructDataType.add(StructConverter.DWORD, "zero1", null);
        importStructDataType.add(StructConverter.DWORD, "zero2", null);
        importStructDataType.add(StructConverter.DWORD, "name", null);
        importStructDataType.add(StructConverter.DWORD, "fnid", null);
        importStructDataType.add(StructConverter.DWORD, "stub", null);
        importStructDataType.add(StructConverter.DWORD, "zero3", null);
        importStructDataType.add(StructConverter.DWORD, "zero4", null);
        importStructDataType.add(StructConverter.DWORD, "zero5", null);
        importStructDataType.add(StructConverter.DWORD, "zero6", null);
    }


    StructureDataType exportStructDataType;
    private void createExportStruc() {
        exportStructDataType = new StructureDataType(new CategoryPath("/PS3"), "ExportStub_s", 0);
        exportStructDataType.add(StructConverter.WORD, "ssize", null);
        exportStructDataType.add(StructConverter.WORD, "header1", null);
        exportStructDataType.add(StructConverter.WORD, "header2", null);
        exportStructDataType.add(StructConverter.WORD, "exports", null);
        exportStructDataType.add(StructConverter.DWORD, "zero1", null);
        exportStructDataType.add(StructConverter.DWORD, "zero2", null);
        exportStructDataType.add(StructConverter.DWORD, "noname", null);
        exportStructDataType.add(StructConverter.DWORD, "fnid", null);
        exportStructDataType.add(StructConverter.DWORD, "stub", null);
    }

    StructureDataType opdStructDataType;
    private void createOpdStruct() {
        opdStructDataType = new StructureDataType(new CategoryPath("/PS3"), "OPD_s", 0);
        opdStructDataType.add(StructConverter.DWORD, "sub", null);
        opdStructDataType.add(StructConverter.DWORD, "toc", null);
        //opdStructDataType.add(StructConverter.QWORD, "env", null);
    }


    private void applyStruct(StructureDataType struct, Address address) throws Exception {
        clearListing(address, address.add(struct.getLength()));
        createData(address, struct);
        createLabel(address, struct.getName(), true);
    }

    private void createOpd(Address toc_addr) {
        createOpdStruct();

        println("Defining OPD entries");

        long ea = toc_addr.getOffset() - 0x8000;

        try {

            /* Find last OPD entry */

            while (listing.getCodeUnitAt(toc_addr.getNewAddress(ea - 0x04)).getInt(0) != toc_addr.getOffset()) {
                ea = ea - 0x04;
            }

            try {
                while (listing.getCodeUnitAt(toc_addr.getNewAddress(ea - 0x04)).getInt(0) == toc_addr.getOffset()) {
                    ea -= 0x08;
                    Address toc_struc_addr = toc_addr.getNewAddress(ea);
                    applyStruct(opdStructDataType, toc_struc_addr);
                    //TODO createfunction?
                    int func_ptr = listing.getCodeUnitAt(toc_struc_addr).getInt(0);
                    //createFunction(toc_addr.getNewAddress(func_ptr), null);
                }
            } catch (Exception e) {
                printf("Exploded at opd struc 0x%X\n", ea);
            }


        } catch (Exception e) {
            println("Well shit, createOpd exploded");
            ConsoleService console = state.getTool().getService(ConsoleService.class);
            console.addException("ugh", e);
        }
    }


    private Address findToc(MemoryBlock opt_seg) throws Exception {
        Address toc = opt_seg.getStart().getNewAddress(listing.getCodeUnitAt(opt_seg.getStart().add(0x04)).getInt(0));
        createLabel(toc, "TOC", true);
        return toc;
    }

    private MemoryBlock findOpd() throws MemoryAccessException, LockException, DuplicateNameException {

        long ea;

        MemoryBlock opt_seg = null;
        for (MemoryBlock block : currentProgram.getMemory().getBlocks()) {
            for(ea = block.getStart().getOffset(); ea + 8 < block.getEnd().getOffset() + 0x1000; ea = ea + 8) {
                Address toc = block.getStart().getNewAddress(ea + 0x04);
                Address next_toc = block.getStart().getNewAddress(ea + 0x0C);

                try {
                    int tocint = listing.getCodeUnitAt(toc).getInt(0);
                    int nexttocint = listing.getCodeUnitAt(next_toc).getInt(0);

                    if (tocint == 0 || tocint == 0xFFFFFFFF || tocint != nexttocint) {
                        break;
                    }

                    opt_seg = block;
                } catch (Exception e) {
                    //TODO handle properly
                }
            }
        }

        if(opt_seg != null) {
            opt_seg.setName("OPD");
            printf("Found OPD: 0x%X - TOC = 0x%X\n", opt_seg.getStart().getOffset(), listing.getCodeUnitAt(opt_seg.getStart().add(0x04)).getInt(0));
        }

        return opt_seg;
    }





}
