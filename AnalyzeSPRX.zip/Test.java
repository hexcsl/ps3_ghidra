import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Node;
import org.apache.logging.log4j.core.config.json.JsonConfiguration;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONObject;

public class Test {


    public static void main(String[] args) throws Exception {
        System.out.println(783 % 0x1C);
        System.out.println(784 % 0x1C);

        if(1 == 1) {
            convertwiki();
            return;
        }

        String moduleName = "cellRtc";
        int fnid = 0xF582308D;


        JSONObject jsonObject = new JSONObject(FileUtils.readFileToString(new File("G:\\Projects 2019\\lv2\\ps3ida\\ps3fnids.json")));
        System.out.println(jsonObject);

        JSONArray entries = jsonObject.getJSONObject("Groups").getJSONObject(moduleName).getJSONArray("Entry");
        for (int i = 0; i < entries.length(); i++) {
            JSONObject entry = entries.getJSONObject(i);
            if(entry.getString("_id").equals(String.format("0x%02X", fnid))) {
                System.out.println(entry.get("_name"));
            }
        }


    }

    private static void convertwiki() throws IOException {

        List<String> lines = FileUtils.readLines(new File("G:\\Projects 2019\\lv2\\ps3ida\\newnids\\wiki.txt"));
        JSONObject jsonObject = new JSONObject(FileUtils.readFileToString(new File("G:\\Projects 2019\\lv2\\ps3ida\\newnids\\ps3fnids-old.json")));
        JSONObject groups = jsonObject.getJSONObject("Groups");

        JSONArray entries = null;

        String currentModule = "";
        for (String line : lines) {
            if(line.startsWith("===")) {
                currentModule = line.replaceAll(Pattern.quote("="), "").trim();

                System.out.println(currentModule);

                if (!groups.has(currentModule)) {
                    groups.put(currentModule, new JSONObject());
                    groups.getJSONObject(currentModule).put("Entry", new JSONArray());
                }

            }

            if(line.startsWith("| 0x")) {

                String[] split = line.split(Pattern.quote("||"));
                String fnid = split[0].substring(2).trim();
                String name= split[1].trim();

                if(!name.contains(" ")) {
                    System.out.println(currentModule + " " + fnid + " " + name);

                    HashMap<String, String> test = new HashMap<String, String>() {{
                        put("_id", fnid);
                        put("_name", name);
                    }};

                    groups.getJSONObject(currentModule).getJSONArray("Entry").put(test);
                }


            }

        }

        String newww = jsonObject.toString();
        FileUtils.write(new File("G:\\Projects 2019\\lv2\\ps3ida\\newnids\\new.json"), newww);


    }

}
