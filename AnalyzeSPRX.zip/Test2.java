import com.google.common.io.BaseEncoding;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ArrayUtils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Test2 {

    public static void main(String[] args) {
        new Test2();
    }

    public Test2() {

        int fnid = 0x1067E22;
        String format = String.format("0x%08X", fnid);
        System.out.println(format);

        byte[] symbol_name_suffix = new byte[]{0x67, 0x59, 0x65, (byte) 0x99, 0x04, 0x25, 0x04, (byte) 0x90, 0x56, 0x64, 0x27, 0x49, (byte) 0x94, (byte) 0x89, 0x74, 0x1A};
        byte[] bytes = ArrayUtils.addAll("_sys_sprintf".getBytes(), symbol_name_suffix);
        String digest = DigestUtils.shaHex(bytes).substring(0, 8).toUpperCase();
        System.out.println("0x"+ digest.substring(6,8) + digest.substring(4,6) + digest.substring(2,4) + digest.substring(0,2));

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            digest = BaseEncoding.base16().upperCase().encode(md.digest(bytes)).substring(0, 8);

            System.out.println("0x"+ digest.substring(6,8) + digest.substring(4,6) + digest.substring(2,4) + digest.substring(0,2));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

}
