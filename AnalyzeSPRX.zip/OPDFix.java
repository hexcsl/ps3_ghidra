import ghidra.app.script.GhidraScript;
import ghidra.app.util.bin.format.pef.PefConstants;
import ghidra.program.model.address.Address;
import ghidra.program.model.data.PointerDataType;
import ghidra.program.model.listing.Listing;
import ghidra.program.model.listing.Program;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.Symbol;
import ghidra.program.model.symbol.SymbolTable;
import ghidra.program.model.symbol.SymbolUtilities;

public class OPDFix extends GhidraScript {

    @Override
    protected void run() throws Exception {
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        Listing listing = currentProgram.getListing();

        //Symbol opdSymbol = SymbolUtilities.getExpectedLabelOrFunctionSymbol(currentProgram,
        //        ".opd", err -> println(err));


        MemoryBlock opdBlock = currentProgram.getMemory().getBlock("EMPTYNAME_0x35b508");//Stuipid ghidra bug
        println("moo "+opdBlock.getStart().getOffset()+" "+opdBlock.getEnd().getOffset());

        long start = opdBlock.getStart().getOffset();
        long end = opdBlock.getEnd().getOffset();

        int i = 0;
        //for (long pos = start; pos <= end; pos+=24) {
        for (long pos = end; pos >= start; pos-=24) {

            Address newAddress = opdBlock.getStart().getNewAddress(pos);
            try {
                //listing.createData(newAddress, PointerDataType.dataType);
            } catch (Exception e){}

            try {
                long funcPtrLong = listing.getCodeUnitAt(newAddress).getLong(0);

                if (getFunctionAt(opdBlock.getStart().getNewAddress(funcPtrLong)) == null) {
                    if (i < 5000) {
                        createFunction(opdBlock.getStart().getNewAddress(funcPtrLong), null);
                        printf("ugh function -> 0x%X %d\n", funcPtrLong, i++);
                    } else {
                        break;
                    }
                }
            } catch (Exception e) {
                printf("oof function -> 0x%X\n", pos);

            }

        }


    }

}
