import ghidra.app.script.GhidraScript;
import ghidra.app.services.ConsoleService;
import ghidra.app.util.bin.StructConverter;
import ghidra.program.model.address.Address;
import ghidra.program.model.data.CategoryPath;
import ghidra.program.model.data.QWordDataType;
import ghidra.program.model.data.StructureDataType;
import ghidra.program.model.listing.CodeUnit;
import ghidra.program.model.listing.Listing;
import ghidra.program.model.mem.MemoryAccessException;
import ghidra.program.model.symbol.SourceType;
import ghidra.program.model.symbol.SymbolTable;
import ghidra.util.exception.CancelledException;

import java.util.Arrays;

import static ghidra.program.model.listing.CodeUnit.PRE_COMMENT;

@SuppressWarnings({"ConstantConditions", "unused"})
public class LV2TOCFinderScript extends GhidraScript {


    Listing listing;
    SymbolTable symbolTable;


    StructureDataType tocStructDataType;
    StructureDataType opdStructDataType;

    private void createTocStruct() {
        tocStructDataType = new StructureDataType(new CategoryPath("/PS3"), "TOC", 0);
        tocStructDataType.add(StructConverter.QWORD, "toc", null);
    }

    private void createOpdStruct() {
        opdStructDataType = new StructureDataType(new CategoryPath("/PS3"), "OPD", 0);
        opdStructDataType.add(StructConverter.POINTER, "sub", null);
        opdStructDataType.add(StructConverter.POINTER, "toc", null);
        opdStructDataType.add(StructConverter.QWORD, "env", null);
    }

    private void applyStruct(StructureDataType struct, Address address) throws Exception {
        clearListing(address, address.add(struct.getLength()));
        createData(address, struct);
        createLabel(address, struct.getName(), true);
    }

    private void createStructs() {
        createTocStruct();
        createOpdStruct();
    }


    public void stuff() {
        Address syscall_table = findSyscallTable();
        Address toc = null;

        if (syscall_table == null) {
            println("Could not find the syscall table\n");
            return;
        }

        createSyscallTable(syscall_table);

        /* Each syscall entry is a TOC entry, so get the toc pointer stored in it */
        try {
            toc = syscall_table.getNewAddress(listing.getCodeUnitAt(syscall_table.getNewAddress(listing.getCodeUnitAt(syscall_table).getLong(0) + 0x08)).getLong(0));
        } catch (MemoryAccessException e) {
            e.printStackTrace();
        }

        if (toc == null) {
            println("Could not find the TOC");
            return;
        }

        printf("*** Found TOC at : 0x%X\n", toc.getOffset());
        createToc(toc);
        createOpd(toc);

        NameHypercalls();

    }

    private void NameHypercalls() {

        //TODO

    }

    private void createOpd(Address toc_addr) {
        createOpdStruct();

        println("Defining OPD entries");

        long ea = toc_addr.getOffset() - 0x8000;

        try {

            byte[] bytesAtToc = listing.getCodeUnitAt(toc_addr).getBytes();

            /* Find last OPD entry */

            while (listing.getDataAt(toc_addr.getNewAddress(ea - 0x10)).getLong(0) != toc_addr.getOffset()) {
                ea = ea - 0x08;
            }

            try {
                while (listing.getCodeUnitAt(toc_addr.getNewAddress(ea - 0x10)).getLong(0) == toc_addr.getOffset()) {
                    ea -= 0x18;
                    applyStruct(opdStructDataType, toc_addr.getNewAddress(ea));
                    //TODO createfunction?
                }
            } catch (Exception e) {
                printf("Exploded at opd struc 0x%X\n", ea);
            }


        } catch (Exception e) {
            println("Well shit, createOpd exploded");
            ConsoleService console = state.getTool().getService(ConsoleService.class);
            console.addException("ugh", e);
        }
    }

    private void createToc(Address toc_addr) {
        try {
            createTocStruct();

            applyStruct(tocStructDataType, toc_addr);

            println("Defining TOC entries");
            long startAddr = toc_addr.getOffset() - 0x8000;
            long endAddr = toc_addr.getOffset() + 0x8000;

            printf("redefining data from 0x%X to 0x%X\n", startAddr, endAddr);

            long ea = startAddr;
            while (ea != endAddr) {
                /**
                 *     MakeUnknown(ea, 0x08, DOUNK_SIMPLE);
                 *     MakeQword(ea);
                 */
                //TODO
                try {
                    clearListing(toc_addr.getNewAddress(ea));
                    createData(toc_addr.getNewAddress(ea), QWordDataType.dataType);
                } catch (Exception e) {
                    //TODO fix properly
                }
                ea += 0x08;
            }
        } catch (Exception e) {
            println("Well shit, createToc exploded");
            ConsoleService console = state.getTool().getService(ConsoleService.class);
            console.addException("ugh", e);
        }

    }

    private void createSyscallTable(Address syscall_table) {
        Listing listing = currentProgram.getListing();

        try {
            //ida MakeName(syscall_table, "syscall_table");
            currentProgram.getSymbolTable().createLabel(syscall_table, "syscall_table", SourceType.USER_DEFINED);

            println("Naming syscall elements");

            /* Search last to first to get the not_implemented syscall named correctly as sc0 */
            for (int i = 1023; i != -1; i--) {
                String name = get_lv2_rawname(i);

                //TODO

                //listing.createData(syscall_table.getNewAddress(syscall_table.getOffset() + 8 * i), QWordDataType.dataType);//Ghidra seems to already define this
                listing.setComment(syscall_table.getNewAddress(syscall_table.getOffset() + 8 * i), PRE_COMMENT, "Syscall " + i);

                CodeUnit codeUnitAt = listing.getCodeUnitAt(syscall_table.getNewAddress(syscall_table.getOffset() + 8 * i));
                long syscall_desc_addr_long = codeUnitAt.getLong(0);
                //listing.createData(syscall_table.getNewAddress(syscall_desc_addr_long), QWordDataType.dataType);//Ghidra seems to already define this
                currentProgram.getSymbolTable().createLabel(syscall_table.getNewAddress(syscall_desc_addr_long), "syscall_" + name + "_desc", SourceType.ANALYSIS);

                CodeUnit codeUnitAt1 = listing.getCodeUnitAt(syscall_table.getNewAddress(syscall_desc_addr_long));
                long syscall_addr_long = codeUnitAt1.getLong(0);

                //Will this explode?
                createFunction(syscall_table.getNewAddress(syscall_addr_long), "syscall_" + name);


            }

        } catch (Exception e) {
            ConsoleService console = state.getTool().getService(ConsoleService.class);
            console.addException("ugh", e);

            println("oshit");
        }


    }

    private Address findSyscallTable() {

        long ea;
        Address syscallTable = null;

        try {
            syscallTable = askAddress("Syscall table address", "If you know the location of the syscall table, please enter it, otherwise press cancel");
        } catch (CancelledException e) {

        }

        if (syscallTable != null) {
            if (isSyscallTable(syscallTable.getOffset())) {//is getOffset right?
                println("Entered syscall table seems valid, proceding..");
            } else {
                println("Entered syscall table seems invalid, Will search instead.");
                syscallTable = null;
            }
        }

        //TODO valid address check
        if (syscallTable == null) {
            println("Looking for syscall table..");
            println("This will take some time, please wait...");

            for (ea = 0x8000000000400000L; ea != 0x8000000000000000L; ea -= 8) {
                if ((ea & 0xffff) == 0) {
                    //Turns out this actually runs really fast, not really needed
                    //printf("Currently at 0x%x\n", ea);
                }
                if (isSyscallTable(ea)) {
                    printf("*** Found syscall table at offset 0x%X\n", ea);
                    syscallTable = currentAddress.getNewAddress(ea);
                    break;
                }
            }
        }

        return syscallTable;
    }

    private boolean isSyscallTable(long address) {
        //0x80000000003B28F8 = correct syscall table for 484
        Listing listing = currentProgram.getListing();

        try {
            CodeUnit dataAtAddress = listing.getCodeUnitAt(currentAddress.getNewAddress(address));
            byte[] bytesAtAddress = dataAtAddress.getBytes();

            if (
                //SYSCALL check, checks if the 'unimplemented' syscalls point at a different address to syscall0
                    !Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 1))).getBytes(), bytesAtAddress) &&
                            !Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 2))).getBytes(), bytesAtAddress) &&
                            !Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 3))).getBytes(), bytesAtAddress) &&
                            !Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 14))).getBytes(), bytesAtAddress) &&
                            Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 15))).getBytes(), bytesAtAddress) &&
                            Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 16))).getBytes(), bytesAtAddress) &&
                            Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 17))).getBytes(), bytesAtAddress) &&
                            !Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 18))).getBytes(), bytesAtAddress) &&
                            !Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 19))).getBytes(), bytesAtAddress) &&
                            Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 20))).getBytes(), bytesAtAddress) &&
                            !Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 21))).getBytes(), bytesAtAddress) &&
                            Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 32))).getBytes(), bytesAtAddress) &&
                            Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 33))).getBytes(), bytesAtAddress) &&
                            !Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 41))).getBytes(), bytesAtAddress) &&
                            Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 42))).getBytes(), bytesAtAddress) &&
                            !Arrays.equals(listing.getCodeUnitAt(currentAddress.getNewAddress(address + (8 * 43))).getBytes(), bytesAtAddress)
            ) {
                return true;
            }
        } catch (Exception e) {
            //This will explode a lot until it finds the right data
        }

        return false;
    }

    @Override
    public void run() throws Exception {

        listing = currentProgram.getListing();
        symbolTable = currentProgram.getSymbolTable();

        if (1 == 1) {
            stuff();
            return;
        }

        /*
        listing = currentProgram.getListing();
        symbolTable = currentProgram.getSymbolTable();

        // Find .toc symbol
        Symbol toc = SymbolUtilities.getExpectedLabelOrFunctionSymbol(currentProgram, ".toc",
                err -> Msg.error(this, err));
        if (toc == null) {
            popup("Couldn't find a toc :(");
            return;
        }
        Address tocAddress = toc.getAddress();
        popup("Found toc at "+tocAddress.toString());

        // Get direct refs to .toc
        monitor.setMessage("Finding references to .toc");
        FindReferencesTableModel refs =
                new FindReferencesTableModel(tocAddress, state.getTool(), currentProgram);
        while (refs.isBusy()) {
            if (monitor.isCancelled()) {
                break;
            }
        }

        // Loop through refs to find functions
        for (int i = 0; i < refs.getRowCount(); ++i) {
            monitor.setMessage("Finding functions");
            if (monitor.isCancelled()) {
                break;
            }

            // Make them pointers to .toc
            Address refAddr = refs.getAddress(i);
            listing.clearCodeUnits(refAddr, refAddr, false);
            listing.createData(refAddr, new PointerDataType());

            // Make previous code unit (addr-addrSize) a pointer
            Address codeAddr = refAddr.subtract(addrSize);
            listing.clearCodeUnits(codeAddr, codeAddr, false);
            CreateDataCmd cmd = new CreateDataCmd(codeAddr, new PointerDataType());
            cmd.applyTo(currentProgram);
// 	 		listing.createData(codeAddr, new PointerDataType());

            currentProgram.flushEvents();
        }

        popup("Script complete.\n\nNote:  Auto analyzer may still be running.\n" +
                "(Depending on the size of the binary, analysis may take a while...see Ghidra's progress bar.)");
                */

    }


    private String get_lv2_rawname(int num) {
        if (num == 0) return "not_implemented";
        else if (num == 1) return "sys_process_getpid";
        else if (num == 2) return "sys_process_wait_for_child";
        else if (num == 4) return "sys_process_get_status";
        else if (num == 5) return "sys_process_detach_child";
        else if (num == 12) return "sys_process_get_number_of_object";
        else if (num == 13) return "sys_process_get_id";
        else if (num == 14) return "sys_process_is_spu_lock_line_reservation_address";
        else if (num == 18) return "sys_process_getppid";
        else if (num == 19) return "sys_process_kill";
        else if (num == 23) return "sys_process_wait_for_child2";
        else if (num == 25) return "sys_process_get_sdk_version";
        else if (num == 43) return "sys_ppu_thread_yield";
        else if (num == 44) return "sys_ppu_thread_join";
        else if (num == 45) return "sys_ppu_thread_detach";
        else if (num == 46) return "sys_ppu_thread_get_join_state";
        else if (num == 47) return "sys_ppu_thread_set_priority";
        else if (num == 48) return "sys_ppu_thread_get_priority";
        else if (num == 49) return "sys_ppu_thread_get_stack_information";
        else if (num == 56) return "sys_ppu_thread_rename";
        else if (num == 57) return "sys_ppu_thread_recover_page_fault";
        else if (num == 67) return "sys_trace_allocate_buffer";
        else if (num == 68) return "sys_trace_free_buffer";
        else if (num == 69) return "sys_trace_create2";
        else if (num == 70) return "sys_timer_create";
        else if (num == 71) return "sys_timer_destroy";
        else if (num == 72) return "sys_timer_get_information";
        else if (num == 73) return "_sys_timer_start";
        else if (num == 74) return "sys_timer_stop";
        else if (num == 75) return "sys_timer_connect_event_queue";
        else if (num == 76) return "sys_timer_disconnect_event_queue";
        else if (num == 80) return "sys_interrupt_tag_create";
        else if (num == 81) return "sys_interrupt_tag_destroy";
        else if (num == 84) return "_sys_interrupt_thread_establish";
        else if (num == 88) return "sys_interrupt_thread_eoi";
        else if (num == 89) return "_sys_interrupt_thread_disestablish";
        else if (num == 90) return "sys_semaphore_create";
        else if (num == 91) return "sys_semaphore_destroy";
        else if (num == 92) return "sys_semaphore_wait";
        else if (num == 93) return "sys_semaphore_trywait";
        else if (num == 94) return "sys_semaphore_post";
        else if (num == 100) return "sys_mutex_create";
        else if (num == 101) return "sys_mutex_destroy";
        else if (num == 102) return "sys_mutex_lock";
        else if (num == 103) return "sys_mutex_trylock";
        else if (num == 104) return "sys_mutex_unlock";
        else if (num == 105) return "sys_cond_create";
        else if (num == 106) return "sys_cond_destroy";
        else if (num == 107) return "sys_cond_wait";
        else if (num == 108) return "sys_cond_signal";
        else if (num == 109) return "sys_cond_signal_all";
        else if (num == 110) return "sys_cond_signal_to";
        else if (num == 114) return "sys_semaphore_get_value";
        else if (num == 120) return "sys_rwlock_create";
        else if (num == 121) return "sys_rwlock_destroy";
        else if (num == 122) return "sys_rwlock_rlock";
        else if (num == 123) return "sys_rwlock_tryrlock";
        else if (num == 124) return "sys_rwlock_runlock";
        else if (num == 125) return "sys_rwlock_wlock";
        else if (num == 126) return "sys_rwlock_trywlock";
        else if (num == 127) return "sys_rwlock_wunlock";
        else if (num == 128) return "sys_event_queue_create";
        else if (num == 129) return "sys_event_queue_destroy";
        else if (num == 130) return "sys_event_queue_receive";
        else if (num == 131) return "sys_event_queue_tryreceive";
        else if (num == 133) return "sys_event_queue_drain";
        else if (num == 134) return "sys_event_port_create";
        else if (num == 135) return "sys_event_port_destroy";
        else if (num == 136) return "sys_event_port_connect_local";
        else if (num == 137) return "sys_event_port_disconnect";
        else if (num == 138) return "sys_event_port_send";
        else if (num == 140) return "sys_event_port_connect_ipc";
        else if (num == 141) return "sys_timer_usleep";
        else if (num == 142) return "sys_timer_sleep";
        else if (num == 145) return "sys_time_get_current_time";
        else if (num == 147) return "sys_time_get_timebase_frequency";
        else if (num == 150) return "sys_raw_spu_create_interrupt_tag";
        else if (num == 151) return "sys_raw_spu_set_int_mask";
        else if (num == 152) return "sys_raw_spu_get_int_mask";
        else if (num == 153) return "sys_raw_spu_set_int_stat";
        else if (num == 154) return "sys_raw_spu_get_int_stat";
        else if (num == 156) return "sys_spu_image_open";
        else if (num == 160) return "sys_raw_spu_create";
        else if (num == 161) return "sys_raw_spu_destroy";
        else if (num == 163) return "sys_raw_spu_read_puint_mb";
        else if (num == 165) return "sys_spu_thread_get_exit_status";
        else if (num == 166) return "sys_spu_thread_set_argument";
        else if (num == 167) return "sys_spu_thread_group_start_on_exit";
        else if (num == 169) return "sys_spu_initialize";
        else if (num == 170) return "sys_spu_thread_group_create";
        else if (num == 171) return "sys_spu_thread_group_destroy";
        else if (num == 172) return "sys_spu_thread_initialize";
        else if (num == 173) return "sys_spu_thread_group_start";
        else if (num == 174) return "sys_spu_thread_group_suspend";
        else if (num == 175) return "sys_spu_thread_group_resume";
        else if (num == 176) return "sys_spu_thread_group_yield";
        else if (num == 177) return "sys_spu_thread_group_terminate";
        else if (num == 178) return "sys_spu_thread_group_join";
        else if (num == 179) return "sys_spu_thread_group_set_priority";
        else if (num == 180) return "sys_spu_thread_group_get_priority";
        else if (num == 181) return "sys_spu_thread_write_ls";
        else if (num == 182) return "sys_spu_thread_read_ls";
        else if (num == 184) return "sys_spu_thread_write_snr";
        else if (num == 185) return "sys_spu_thread_group_connect_event";
        else if (num == 186) return "sys_spu_thread_group_disconnect_event";
        else if (num == 187) return "sys_spu_thread_set_spu_cfg";
        else if (num == 188) return "sys_spu_thread_get_spu_cfg";
        else if (num == 190) return "sys_spu_thread_write_spu_mb";
        else if (num == 191) return "sys_spu_thread_connect_event";
        else if (num == 192) return "sys_spu_thread_disconnect_event";
        else if (num == 193) return "sys_spu_thread_bind_queue";
        else if (num == 194) return "sys_spu_thread_unbind_queue";
        else if (num == 196) return "sys_raw_spu_set_spu_cfg";
        else if (num == 197) return "sys_raw_spu_get_spu_cfg";
        else if (num == 198) return "sys_spu_thread_recover_page_fault";
        else if (num == 199) return "sys_raw_spu_recover_page_fault";
        else if (num == 251) return "sys_spu_thread_group_connect_event_all_threads";
        else if (num == 252) return "sys_spu_thread_group_disconnect_event_all_threads";
        else if (num == 260) return "sys_spu_image_open_by_fd";
        else if (num == 327) return "sys_mmapper_enable_page_fault_notification";
        else if (num == 329) return "sys_mmapper_free_shared_memory";
        else if (num == 330) return "sys_mmapper_allocate_address";
        else if (num == 331) return "sys_mmapper_free_address";
        else if (num == 332) return "sys_mmapper_allocate_shared_memory";
        else if (num == 333) return "sys_mmapper_set_shared_memory_flag";
        else if (num == 334) return "sys_mmapper_map_shared_memory";
        else if (num == 335) return "sys_mmapper_unmap_shared_memory";
        else if (num == 336) return "sys_mmapper_change_address_access_right";
        else if (num == 337) return "sys_mmapper_search_and_map";
        else if (num == 338) return "sys_mmapper_get_shared_memory_attribute";
        else if (num == 341) return "sys_memory_container_create";
        else if (num == 342) return "sys_memory_container_destroy";
        else if (num == 343) return "sys_memory_container_get_size";
        else if (num == 348) return "sys_memory_allocate";
        else if (num == 349) return "sys_memory_free";
        else if (num == 350) return "sys_memory_allocate_from_container";
        else if (num == 351) return "sys_memory_get_page_attribute";
        else if (num == 352) return "sys_memory_get_user_memory_size";
        else if (num == 402) return "sys_tty_read";
        else if (num == 403) return "sys_tty_write";
        else if (num == 450) return "sys_overlay_load_module";
        else if (num == 451) return "sys_overlay_unload_module";
        else if (num == 452) return "sys_overlay_get_module_list";
        else if (num == 453) return "sys_overlay_get_module_info";
        else if (num == 454) return "sys_overlay_load_module_by_fd";
        else if (num == 455) return "sys_overlay_get_module_info2";
        else if (num == 456) return "sys_overlay_get_sdk_version";
        else if (num == 457) return "sys_overlay_get_module_dbg_info";
        else if (num == 461) return "_sys_prx_get_module_id_by_address";
        else if (num == 463) return "_sys_prx_load_module_by_fd";
        else if (num == 464) return "_sys_prx_load_module_on_memcontainer_by_fd";
        else if (num == 480) return "_sys_prx_load_module";
        else if (num == 481) return "_sys_prx_start_module";
        else if (num == 482) return "_sys_prx_stop_module";
        else if (num == 483) return "_sys_prx_unload_module";
        else if (num == 484) return "_sys_prx_register_module";
        else if (num == 485) return "_sys_prx_query_module";
        else if (num == 486) return "_sys_prx_register_library";
        else if (num == 487) return "_sys_prx_unregister_library";
        else if (num == 488) return "_sys_prx_link_library";
        else if (num == 489) return "_sys_prx_unlink_library";
        else if (num == 490) return "_sys_prx_query_library";
        else if (num == 494) return "_sys_prx_get_module_list";
        else if (num == 495) return "_sys_prx_get_module_info";
        else if (num == 496) return "_sys_prx_get_module_id_by_name";
        else if (num == 497) return "_sys_prx_load_module_on_memcontainer";
        else if (num == 498) return "_sys_prx_start";
        else if (num == 499) return "_sys_prx_stop";
        else if (num == 600) return "sys_storage_open";
        else if (num == 601) return "sys_storage_close";
        else if (num == 602) return "sys_storage_read";
        else if (num == 603) return "sys_storage_write";
        else if (num == 604) return "sys_storage_send_device_command";
        else if (num == 605) return "sys_storage_async_configure";
        else if (num == 606) return "sys_storage_async_read";
        else if (num == 607) return "sys_storage_async_write";
        else if (num == 608) return "sys_storage_async_cancel";
        else if (num == 609) return "sys_storage_get_device_info";
        else if (num == 610) return "sys_storage_get_device_config";
        else if (num == 611) return "sys_storage_report_devices";
        else if (num == 612) return "sys_storage_configure_medium_event";
        else if (num == 613) return "sys_storage_set_medium_polling_interval";
        else if (num == 614) return "sys_storage_create_region";
        else if (num == 615) return "sys_storage_delete_region";
        else if (num == 616) return "sys_storage_execute_device_command";
        else if (num == 617) return "sys_storage_get_region_acl";
        else if (num == 618) return "sys_storage_set_region_acl";
        else if (num == 619) return "sys_storage_async_send_device_command";
        else if (num == 624) return "sys_io_buffer_create";
        else if (num == 625) return "sys_io_buffer_destroy";
        else if (num == 626) return "sys_io_buffer_allocate";
        else if (num == 627) return "sys_io_buffer_free";
        else if (num == 630) return "sys_gpio_set";
        else if (num == 631) return "sys_gpio_get";
        else if (num == 633) return "sys_fsw_connect_event";
        else if (num == 634) return "sys_fsw_disconnect_event";
        else if (num == 666) return "sys_rsx_device_open";
        else if (num == 667) return "sys_rsx_device_close";
        else if (num == 668) return "sys_rsx_memory_allocate";
        else if (num == 669) return "sys_rsx_memory_free";
        else if (num == 670) return "sys_rsx_context_allocate";
        else if (num == 671) return "sys_rsx_context_free";
        else if (num == 672) return "sys_rsx_context_iomap";
        else if (num == 673) return "sys_rsx_context_iounmap";
        else if (num == 674) return "sys_rsx_context_attribute";
        else if (num == 675) return "sys_rsx_device_map";
        else if (num == 676) return "sys_rsx_device_unmap";
        else if (num == 677) return "sys_rsx_attribute";
        else if (num == 801) return "open";
        else if (num == 802) return "read";
        else if (num == 803) return "write";
        else if (num == 804) return "close";
        else if (num == 805) return "opendir";
        else if (num == 806) return "readdir";
        else if (num == 807) return "closedir";
        else if (num == 808) return "stat";
        else if (num == 809) return "fstat";
        else if (num == 810) return "link";
        else if (num == 811) return "mkdir";
        else if (num == 812) return "rename";
        else if (num == 813) return "rmdir";
        else if (num == 814) return "unlink";
        else if (num == 815) return "utime";
        else if (num == 818) return "lseek";
        else if (num == 820) return "fsync";
        else if (num == 831) return "truncate";
        else if (num == 832) return "ftruncate";
        else if (num == 834) return "chmod";
        else if (num == 837) return "mount";
        else if (num == 872) return "sys_ss_get_open_psid";
        else if (num == 873) return "sys_ss_get_cache_of_product_mode";
        else if (num == 880) return "sys_deci3_open";
        else if (num == 881) return "sys_deci3_create_event_path";
        else if (num == 882) return "sys_deci3_close";
        else if (num == 883) return "sys_deci3_send";
        else if (num == 884) return "sys_deci3_receive";
        else
            return "" + num;
    }


}
