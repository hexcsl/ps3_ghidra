import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

public class Test3 {

    public static void main(String[] args) throws Exception {
        new Test3();
    }

    public Test3() throws Exception {

        if(1 == 2) {
            fixJson();
            return;
        }

        List<String> missing = FileUtils.readLines(new File("G:\\Projects 2019\\lv2\\ps3ida\\newnids\\missings.txt"));

        File folder = new File("G:\\Projects 2019\\lv2\\ps3ida\\newnids\\085");

        HashMap<String, String> fnidToNames = new HashMap<>();
        Collection<File> files = FileUtils.listFiles(folder, null, true);
        for (File file : files) {
            for (String readLine : FileUtils.readLines(file)) {
                String[] s = readLine.split(Pattern.quote(" "));
                fnidToNames.put(s[0], s[1]);
            }
        }

        for (String s : missing) {
            String substring = s.substring(s.lastIndexOf(" ")+1);
            if(fnidToNames.get(substring) != null) {
                System.out.println("Found nid! "+substring+" "+fnidToNames.get(substring));
            }
        }



    }

    private void fixJson() throws Exception {
        JSONObject jsonObject = new JSONObject(FileUtils.readFileToString(new File("G:\\Projects 2019\\lv2\\ps3ida\\newnids\\ps3fnids.json")));
        JSONObject groups = jsonObject.getJSONObject("Groups");

        for (String group : groups.keySet()) {
            Iterator<Object> entry = groups.getJSONObject(group).getJSONArray("Entry").iterator();
            entry.forEachRemaining(e -> {
                JSONObject jsonObject1 = (JSONObject)e;
                String id = jsonObject1.getString("_id");
                if(id.length() != 10 && id.length() > 6)
                    System.out.println(id);

            });
        }

    }

}
