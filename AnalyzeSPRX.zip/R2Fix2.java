import ghidra.app.script.GhidraScript;
import ghidra.app.util.bin.format.pef.PefConstants;
import ghidra.app.util.importer.MessageLog;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.lang.Register;
import ghidra.program.model.lang.RegisterValue;
import ghidra.program.model.listing.*;
import ghidra.program.model.mem.MemoryAccessException;
import ghidra.program.model.scalar.Scalar;
import ghidra.program.model.symbol.*;
import ghidra.util.task.TaskMonitor;

import java.math.BigInteger;

@SuppressWarnings("Duplicates")
public class R2Fix2 extends GhidraScript {

	@Override
	protected void run() throws Exception {

		added(currentProgram);
	}


	/**
	 * Creates a reference on any operand that uses
	 * reads an offset from r2.
	 */
	public boolean added(Program program) throws MemoryAccessException {
		SymbolTable symbolTable = program.getSymbolTable();
		Listing listing = program.getListing();
		ReferenceManager referenceManager = program.getReferenceManager();
		Symbol tocSymbol = SymbolUtilities.getExpectedLabelOrFunctionSymbol(program,
			PefConstants.TOC, err -> println(err));
		if (tocSymbol == null) {
			return true;
		}
		AddressSet instructionSet =
			getInstructionSet(program, listing, tocSymbol);
		InstructionIterator instructions = listing.getInstructions(instructionSet, true);
		while (instructions.hasNext()) {

			Instruction instruction = instructions.next();
			if (instruction.getNumOperands() != 2) {
				continue;
			}
			Object[] operandObjects1 = instruction.getOpObjects(1);//op objects from 1st operand
			if (operandObjects1.length != 2) {
				continue;
			}
			if (!(operandObjects1[0] instanceof Scalar)) {
				continue;
			}
			if (!(operandObjects1[1] instanceof Register)) {
				continue;
			}
			Register register = (Register) operandObjects1[1];
			if (!register.getName().equals("r2")) {
				continue;
			}
			Scalar scalar = (Scalar) operandObjects1[0];
			Address destAddr = createReference(referenceManager, tocSymbol, instruction, scalar);
			markupGlueCode(listing, symbolTable, instruction, destAddr);
		}
		return true;
	}

	/**
	 * Creates a address set consisting of the function bodies of each
	 * function entry point specified in the function address set.
	 */
	private AddressSet getInstructionSet(Program program,
										 Listing listing, Symbol tocSymbol) {
		AddressSet instructionSet = new AddressSet();
		FunctionIterator functions = listing.getFunctions(true);
		Register r2 = program.getRegister("r2");
		BigInteger val = BigInteger.valueOf(tocSymbol.getAddress().getOffset());
		RegisterValue regVal = new RegisterValue(r2, val);
		while (functions.hasNext()) {
			if (monitor.isCancelled()) {
				break;
			}
			Function function = functions.next();
			try {
				program.getProgramContext().setRegisterValue(function.getEntryPoint(),
					function.getEntryPoint(), regVal);
			}
			catch (ContextChangeException e) {
				// should never happen when changing r2 register
			}
			instructionSet.add(function.getBody());
		}
		return instructionSet;
	}

	/**
	 * Checks for glue code and propagates the function name up.
	 * <p>
	 * If the instruction is in the form of:
	 * <p>
	 * <code>lwz r12,0x20(r2)</code>
	 * <p>
	 * Then it renames the function containing the instruction
	 * with the symbol's name defined at the address computed
	 * using 0x20(r2).
	 */
	private void markupGlueCode(Listing listing, SymbolTable symbolTable, Instruction instruction,
			Address symbolAddress) {

		Object[] operandObjects0 = instruction.getOpObjects(0);//op objects from 0th operand
		if (operandObjects0.length != 1) {
			return;
		}
		if (!(operandObjects0[0] instanceof Register)) {
			return;
		}
		Register register = (Register) operandObjects0[0];
		if (!register.getName().equals("r12")) {
			return;
		}
		if (!instruction.getMnemonicString().equals("lwz")) {
			return;
		}
		Function function = listing.getFunctionContaining(instruction.getMinAddress());
		if (function == null) {
			return;
		}
		if (function.getSymbol().getSource() == SourceType.IMPORTED ||
			function.getSymbol().getSource() == SourceType.USER_DEFINED) {
			return;
		}
		Symbol symbol = symbolTable.getPrimarySymbol(symbolAddress);
		if (symbol == null || symbol.isDynamic()) {
			return;
		}
		try {
			Namespace glueNamespace = getNamespace(symbolTable, PefConstants.GLUE);
			function.getSymbol().setNamespace(glueNamespace);
			function.getSymbol().setName(symbol.getName(), SourceType.ANALYSIS);
		}
		catch (Exception e) {//don't care
		}
	}

	private Address createReference(ReferenceManager referenceManager, Symbol tocSymbol,
			Instruction instruction, Scalar scalar) throws MemoryAccessException {
		//Address destinationAddress = tocSymbol.getAddress().add(scalar.getSignedValue());
		Address destinationAddressPtr = tocSymbol.getAddress().add(scalar.getSignedValue());
		Address destinationAddress = tocSymbol.getAddress().getNewAddress(currentProgram.getListing().getCodeUnitAt(destinationAddressPtr).getLong(0));//Yay ps3

		Reference reference = referenceManager.addMemoryReference(instruction.getMinAddress(),
			destinationAddress, RefType.READ, SourceType.ANALYSIS, 1);
		referenceManager.setPrimary(reference, false);
		return destinationAddress;
	}

	private Namespace getNamespace(SymbolTable symbolTable, String namespaceName) throws Exception {
		Namespace namespace = symbolTable.getNamespace(namespaceName, null);
		if (namespace == null) {
			namespace = symbolTable.createNameSpace(null, namespaceName, SourceType.IMPORTED);
		}
		return namespace;
	}

}
