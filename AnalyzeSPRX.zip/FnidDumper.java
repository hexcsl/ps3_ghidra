import com.google.common.io.BaseEncoding;
import ghidra.app.script.GhidraScript;
        import ghidra.program.model.address.Address;
        import ghidra.program.model.address.AddressIterator;
        import ghidra.program.model.symbol.Symbol;
        import ghidra.program.model.symbol.SymbolTable;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ArrayUtils;

import java.io.File;
import java.security.MessageDigest;
import java.util.ArrayList;

public class FnidDumper extends GhidraScript {

    @Override
    protected void run() throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");

        File file = askFile("Save fnid list", "Save");

        ArrayList<String> lines = new ArrayList<>();

        SymbolTable symbolTable = currentProgram.getSymbolTable();
        AddressIterator symbols = symbolTable.getExternalEntryPointIterator();
        for (Address symbolAddress : symbols) {
            Symbol primarySymbol = symbolTable.getPrimarySymbol(symbolAddress);

            byte[] symbol_name_suffix = new byte[]{0x67, 0x59, 0x65, (byte) 0x99, 0x04, 0x25, 0x04, (byte) 0x90, 0x56, 0x64, 0x27, 0x49, (byte) 0x94, (byte) 0x89, 0x74, 0x1A};
            byte[] bytes = ArrayUtils.addAll(primarySymbol.getName().getBytes(), symbol_name_suffix);
            String digest = BaseEncoding.base16().upperCase().encode(md.digest(bytes)).substring(0, 8);
            lines.add("0x"+ digest.substring(6,8) + digest.substring(4,6) + digest.substring(2,4) + digest.substring(0,2) +" "+ primarySymbol.getName());
        }

        FileUtils.writeLines(file, lines);

    }



}
